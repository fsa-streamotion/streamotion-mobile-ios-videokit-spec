# PlayableAssetManagerV3 V2

Use PlayAssetManager to fetch a `PlayAsset` that will contain, among other information, the `.m3u8` master playlist to feed `AVPlayer`. 

## Components

This section will describe the components involved in fetching a Playable asset and it will explain some of the architectural decisions taken.


### PlayableAssetManagerV3

`PlaybaleAssetManagerInterface` is the facade clients will interact with.

`PlayableAssetManagerV3` consists of `PlayAssetProvider` and `AdsService. The former is used to retrieve the information of the asset that the user wants to play. The latter is used to retrieve information about the advertisements present in the stream retrieved via the `PlayAssetProvider`. Bear in mind that the Asset returned bt the `PlayAssetProvider` is highly influenced by the information we pass in `AssetInfoV3` at the time of the request. 

### PlayService

`PlayServiceInterfaceV3` defines the interface for retrieving the streams that could be used to play the asset. 

### AdService

`AdsServiceInterface` defines the interface for retrieving the Ads for a particular asset.
