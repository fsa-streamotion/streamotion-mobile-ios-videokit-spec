//
//  FSVideoKit.h
//  FSVideoKit
//
//  Created by Imran Raheem on 25/7/18.
//

#import <UIKit/UIKit.h>

//! Project version number for FSVideoKit.
FOUNDATION_EXPORT double FSVideoKitVersionNumber;

//! Project version string for FSVideoKit.
FOUNDATION_EXPORT const unsigned char FSVideoKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FSVideoKit/PublicHeader.h>


